import copy
game = True
board = []
#Creates a board with 6 rows and 7 columns
default = '_'
defaultrow = []
for i in range(7):
    defaultrow.append(default)
for row in range(6):
    board.append(copy.deepcopy(defaultrow))

#Function prints the board
def printboard():
    for row in range(len(board)):
        print(board[row])

#Inserts a block at the bottom empty slot
def insertBlock(column, player):
    global board
    reversedboard = board[::-1]
    for index, row in enumerate(reversedboard):
        if index == 5 and row[column] != default:
            print('This column is full!')
            return 'Full'
        else:
            if row[column] != default: pass
            elif row[column] == default:
                row.pop(column)
                row.insert(column, player)
                break
    board = reversedboard[::-1]
    return

def validMoveChecker(column):
    if column >= 0 and column <=6: return True
    else: return False

def checkWon():
    #Checks Horizontally if any player won
    for row in board:
        for index, val in enumerate(row):
            try:
                if val == row[index+1] and val == row[index+2] and val == row[index+3] and val != default:
                    printboard()
                    print('Player', currentplayer, 'is the winner!')
                    game = False
                    return True
                    break
            except IndexError:
                next

    #Checks Vertically if any player won
    for column in range(len(board[0])):
        columnvalues = []
        for row in range(len(board)):
            columnvalues.append(board[row][column])
        for index, val in enumerate(columnvalues):
            try:
                if val == columnvalues[index+1] and val == columnvalues[index+2] and val == columnvalues[index+3] and val != default:
                    printboard()
                    print('Player', currentplayer, 'is the winner!')
                    game = False
                    return True
                    break
            except IndexError:
                next

    #Checks Diagonally (up) if any player won
    reversedboard = board[::-1]
    for row in range(0, len(reversedboard)):
        for column in range(0, len(defaultrow)):
            try:
                if reversedboard[row][column] == reversedboard[row+1][column+1] and reversedboard[row][column] == reversedboard[row+2][column+2] and reversedboard[row][column] == reversedboard[row+3][column+3] and reversedboard[row][column] != default:
                    printboard()
                    print('Player', currentplayer, 'is the winner!')
                    game = False
                    return True
            except IndexError:
                next

    #Checks Diagonally (down) if any player won
    for row in range(0, len(board)):
        for column in range(0, len(defaultrow)):
            try:
                if board[row][column] == board[row + 1][column + 1] and board[row][column] == board[row + 2][column + 2] and board[row][column] == board[row + 3][column + 3] and board[row][column] != default:
                    printboard()
                    print('Player', currentplayer, 'is the winner!')
                    game = False
                    return True
            except IndexError:
                next


currentplayer = 'x'
def mainProgram():
    global currentplayer
    print('Any column from 1-7 can be entered')
    print('')
    while game:
        row = ''
        if currentplayer == 'x':
            inputphrase = 'Player X please enter your selected column: '
        else:
            inputphrase = 'Player O please enter your selected column: '
        #Blank space to make program look more clean
        print('')
        printboard()
        playerInput = input(inputphrase)
        #Try/except block to see if the move specified by the player works properly
        try:
            playerInput = int(playerInput) - 1
            if validMoveChecker(playerInput) == False:
                print('This move does not work, please try again.')
            else:
                if currentplayer == 'x':
                    if insertBlock(playerInput, 'x') == 'Full':
                        row = 'Full'
                        next
                elif currentplayer == 'o':
                    if insertBlock(playerInput, 'o') == 'Full':
                        row = 'Full'
                        next
                if checkWon() == True:
                    break
                #Changes currentplayer value for next cycle of while loop to other player
                if currentplayer == 'x' and row != 'Full':
                    currentplayer = 'o'
                elif currentplayer == 'o' and row != 'Full':
                    currentplayer = 'x'
        except ValueError:
            print('This move does not work, please try again.')
    return

mainProgram()